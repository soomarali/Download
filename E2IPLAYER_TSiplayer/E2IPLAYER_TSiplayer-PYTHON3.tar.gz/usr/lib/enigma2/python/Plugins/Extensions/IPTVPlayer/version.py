# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/IPTVPlayer/version.py
IPTV_VERSION = '2023.05.27.01'